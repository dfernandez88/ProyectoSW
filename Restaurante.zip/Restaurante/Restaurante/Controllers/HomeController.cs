﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Restaurante.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Login() 
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(User u) 
        {
            if (ModelState.IsValid)
            {
                using (RestauranteDBEntities dc = new RestauranteDBEntities())
                {
                    var v = dc.Users.Where(a => a.UserName.Equals(u.UserName) && a.Password.Equals(u.Password)).FirstOrDefault();
                    if (v != null) 
                    {
                        Session["LoginUserId"] = v.UserId.ToString();
                        Session["LogedUserName"] = v.UserName.ToString();
                        return RedirectToAction("Index");                        
                    }
                }
            }

            return View(u);
        }

        public ActionResult AfterLogin()
        {
            if (Session["LoginUserId"] != null) 
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        public ActionResult Logout() 
        {
            Session.Clear();
            return RedirectToAction("Index");
        }

        public ActionResult Register() 
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(User u) 
        {
            if (ModelState.IsValid)
            {
                using (RestauranteDBEntities dc = new RestauranteDBEntities())
                {
                    var v = dc.Users.Where(a => a.UserName.Equals(u.UserName)).FirstOrDefault();
                    if (v != null)
                    {
                        return RedirectToAction("Register", new { Message = "Usuario existente, por favor elija otro diferente" });
                    }
                    else 
                    {
                        User n = new User {UserName= u.UserName, Email=u.Email, Password=u.Password, Phone=u.Phone, IsAdmin=u.IsAdmin};
                        dc.Users.Add(n);
                        dc.SaveChanges();
                        return RedirectToAction("Index");
                    }
                }
            }

            return View(u);
        }
    }
}
